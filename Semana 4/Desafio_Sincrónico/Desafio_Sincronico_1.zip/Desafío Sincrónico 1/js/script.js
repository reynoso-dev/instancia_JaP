document.addEventListener("DOMContentLoaded", function () {
  // Escribe el código necesario aquí
  
  //
});
